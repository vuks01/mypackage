#mypackage
this library is created as package for the predict work

## building this package locally
'python setup.py sdist'

## updating this package from GitHub
'pip install git+https://github.com/James-leslie/example-python-package.git'

## updating this package from GitHub
'pip install --upgrade git+https://github.com/James-Leslia/example-python-package.git'